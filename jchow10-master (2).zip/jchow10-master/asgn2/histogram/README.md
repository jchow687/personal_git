PA2 - Histogram

histogram.c : Inputting numbers from stdin within or outside a bin range of 16 to print an histogram

Makefile: This is a shortcut of compiling our c file, where we can make clean to get rid of executables and add our math library

testing.sh : this is where I make testcases in order to check if its pass or fail

testing.out : these are the results/otuput that directed from testing.sh

How to run program? :
lets start off by typing ./histogram
you can input a series of non negative integers with no limit
since the range is 16, you can input a number larger and it will increase the bin size

after you inputted the amount of numbers you wanted, on your keyboard do ctrl d
as it will exit and your numbers will be put into bins, making your first histogram 

Building:
in the command line type "make" to compile the code
then "make clean" after you are done 

-Josh Chow
-Student ID: 1971403
