password checker.c : checks if password contains one uppercase and one lowercase 

test password checker.c : tests cases for the password checker.c file

password checker .h : the header file to password checker.c

Makefile : compiles the code and gets rid .o and exectutables

-Joshua Chow
-1971403 
